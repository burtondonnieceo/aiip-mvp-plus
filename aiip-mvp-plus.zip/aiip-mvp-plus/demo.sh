﻿#!/usr/bin/env bash
set -euo pipefail
GATEWAY=\
MSGID=\
echo '== Health =='; curl -s \/health; echo
echo '== Register two nodes =='
curl -s -X POST \/v1/nodes/register -H 'Content-Type: application/json' -d '{\"owner\":\"alice\",\"endpoint\":\"http://example.com/a\",\"biometricEnabled\":true}'; echo
curl -s -X POST \/v1/nodes/register -H 'Content-Type: application/json' -d '{\"owner\":\"bob\",\"endpoint\":\"http://example.com/b\",\"biometricEnabled\":false}'; echo
echo '== Send message =='
curl -s -X POST \/v1/messages -H 'Content-Type: application/json' -d '{
  "messageId":"''",
  "timestamp":"'2025-09-17T18:20:42Z'",
  "fromNode":"node-1","toNode":"node-2",
  "payload":{"inputType":"sysA.v1","targetType":"sysB.v1","content":{"first_name":"Jane","last_name":"Doe","phone":"(555) 111-2222"}},
  "policy":{"confidentiality":"internal","integrity":"high","retentionDays":30,"allowLLMTransform":false,"allowCrossChain":false},
  "metadata":{"traceId":"script-demo"},"signature":"demo-sig"
}'; echo
sleep 1
echo '== Detail =='; curl -s \/v1/messages//detail; echo
echo '== Ledger entries =='; curl -s "\/v1/ledger/entries?limit=5"; echo
