﻿# AIIP MVP Plus (AIIP 2.0-ready demo)

This runnable demo shows:
- Gateway (FastAPI) → translate → commit digest to ledger
- Translator (FastAPI) → SystemA→SystemB deterministic mapping
- Ledger (FastAPI) → append-only with three Ed25519 signatures
- Console (React+Vite via Nginx)
- Scripted tour (demo.sh)

Quick start:
  docker compose up --build
  # open http://localhost:3000
